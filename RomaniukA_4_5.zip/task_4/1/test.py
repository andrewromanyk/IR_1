a = "abc"

def b(a):
    a = "b"

b(a)
print(a)